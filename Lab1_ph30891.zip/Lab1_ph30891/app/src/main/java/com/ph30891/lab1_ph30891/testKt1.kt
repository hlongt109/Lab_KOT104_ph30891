package com.ph30891.lab1_ph30891

fun cases(obj : Any){
    when(obj){
        1 -> println("One")
        "Hello" -> println("Greating")
    }
}

class testKt1 {
}